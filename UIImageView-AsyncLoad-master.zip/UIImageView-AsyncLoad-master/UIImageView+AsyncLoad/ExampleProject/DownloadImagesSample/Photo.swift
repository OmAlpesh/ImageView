//
//  Photo.swift
//  DownloadImagesSample
//
//  Created by Vinodh Govind Swamy on 3/4/17.
//  Copyright © 2017 Vinodh Swamy. All rights reserved.
//

import UIKit

struct Photo{
    var name : String
    var description : String
    var tumbnailUrl : String
    var originalURl : String
    
}
