//
//  ImageViewCell.swift
//  DownloadImagesSample
//
//  Created by Vinodh Swamy on 12/1/16.
//  Copyright © 2016 Vinodh Swamy. All rights reserved.
//

import UIKit

class TumbnailCell: UICollectionViewCell {
    
    @IBOutlet weak var imageContentView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
